## importing all necessory libraries

import numpy as np
import os
import sys
import re
import math
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import sent_tokenize , word_tokenize
import glob
from pathlib import Path
from collections import Counter
ps=PorterStemmer()
import pandas as pd
import numpy as np

#accessing all required files
with open('../pickle files/doc_fre.pkl','rb') as file:
    doc_fre=pickle.load(file)
    file.close()
    
with open('../pickle files/files_with_index.pkl','rb') as file:
    file_with_index=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_word.pkl','rb') as file:
    doc_words=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_norm.pkl','rb') as file:
    doc_norm=pickle.load(file)
    file.close()

with open('../pickle files/posting_list.pkl','rb') as file:
    posting_list=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_len.pkl','rb') as file:
    doc_len=pickle.load(file)
    file.close()
    
def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

query_list = {}
file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')

for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")

# using dictionary for faster access
li=stopwords.words('english')
Stopwords={}
for i in li:
    Stopwords[i]=1



master_list = {}
rel={}
for k,v in query_list.items():
    master_list[k]=[]
    rel[k]=[]

def cleaning(query):
    #remove the punctuations
    text = re.sub(r'[^\w\s]',' ',query)
    # removing nonascii characters
    encoded_string = text.encode("ascii", "ignore")
    text = encoded_string.decode()
    # tokenizing the doc texts
    tokenize_words=word_tokenize(text)
    # lower all the words
    tokenize_words = [word.lower() for word in tokenize_words]
    #procedure to convert num to words
    temp=[]
    for w in tokenize_words:
        try:
            w=num2words(int(w))
        except:
            pass
        temp.append(w)
    tokenize_words=temp
    # stemming each word
    tokenize_words = [ps.stem(word) for word in tokenize_words]
    #removing all stopwords from query
    tokenize_words=[word for word in tokenize_words if word not in Stopwords]
    #remove all unnecessory words which not present in any dictionary
    words=[word for word in tokenize_words if word in posting_list.keys()]
    return words

## BM25

k=0
N=len(file_with_index)
for i in doc_len:
    k+=doc_len[i]
Lavg=k/N

def bm_for(q,TF,i):
    #calculating idf
    idf=0
    if q in doc_fre:
        idf=doc_fre[q]
    idf=math.log((N-idf+0.5)/(idf+0.5))
    #using bm25 formula.
    ans=idf*(k+1)*TF/(TF+k*(1-b+b*(doc_len[i]/Lavg)))
    return ans

def cal_score(words):
    score={}
    for i in range(len(file_with_index)):
        score[i]=0
        for qi in words:
            TF=0
            if qi in posting_list:
                if i in posting_list[qi]:
                    TF=posting_list[qi][i]
            score[i]+=bm_for(qi,TF,i)
    return score
#calculate total score for query
def score_doc(q):
    words=cleaning(q)
    return cal_score(words)
k=1.2
b=0.75

### Function

for key,value in query_list.items():
    #calculating score according to BM25 formula
    score=score_doc(key)
    final_score = {}
    for i in score:
        final_score[file_with_index[i]]=score[i]
    #sorting the dictionary according to score
    final_score = sorted(final_score.items(),key=lambda x:x[1],reverse=True)
    cnt=5
    for i in final_score:
        if cnt==0:
            break
        cnt-=1
        txt = i[0].split(".")[0]
        master_list[key].append(txt)
        if i[1]==0:
            rel[key].append(0)
        else:
            rel[key].append(1)

df = pd.DataFrame(columns=['QueryId','Iteration','Docid','Relevence'])

final_list = []
the_list = []
for i in range(4):
    the_list.append([])      

for k,v, in query_list.items():
    docid = v
    i=0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name)
        i+=1
    for j in rel[k]:
        the_list[3].append(j)

df['QueryId'] = the_list[0]
df['Iteration'] = the_list[1]
df['Docid'] = the_list[2]
df['Relevence'] = the_list[3]
# df['relevence'] = the_list[4]=

df.to_csv('QRels_BM25.csv',index=False)























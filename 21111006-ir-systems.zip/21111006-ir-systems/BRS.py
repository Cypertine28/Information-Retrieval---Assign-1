## importing all necessory libraries

import numpy as np
import os
import sys
import re
import math
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import sent_tokenize , word_tokenize
import glob
from pathlib import Path
from collections import Counter
ps=PorterStemmer()
import pandas as pd
import numpy as np

#accesing all required pickle files
with open('../pickle files/doc_fre.pkl','rb') as file:
    doc_fre=pickle.load(file)
    file.close()
    
with open('../pickle files/files_with_index.pkl','rb') as file:
    file_with_index=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_word.pkl','rb') as file:
    doc_words=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_norm.pkl','rb') as file:
    doc_norm=pickle.load(file)
    file.close()

with open('../pickle files/posting_list.pkl','rb') as file:
    posting_list=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_len.pkl','rb') as file:
    doc_len=pickle.load(file)
    file.close()

def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

query_list = {}
file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')

for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")

#storing all stopwords into dictionary for faster access
li=stopwords.words('english')
Stopwords={}
for i in li:
    Stopwords[i]=1

master_list = {}
rel={}
for k,v in query_list.items():
    master_list[k]=[]
    rel[k]=[]

#getting all unique words
unique_words=set(posting_list.keys())
# print(len(unique_words))

def cleaning(query):
    #remove the punctuations
    text = re.sub(r'[^\w\s]',' ',query)
    # removing nonascii characters
    encoded_string = text.encode("ascii", "ignore")
    text = encoded_string.decode()
    # tokenizing the doc texts
    tokenize_words=word_tokenize(text)
    # lower all the words
    tokenize_words = [word.lower() for word in tokenize_words]
    #procedure to convert num to words
    temp=[]
    for w in tokenize_words:
        try:
            w=num2words(int(w))
        except:
            pass
        temp.append(w)
    tokenize_words=temp
    # stemming each word
    q_words = [ps.stem(word) for word in tokenize_words]
    #remove all stopwords except "and","or"
    word_list=[]
    for w in q_words:
        if (w not in Stopwords):
            word_list.append(w)
    q_words=word_list
    return q_words

li1=["and","or"]

def add(q_words):
    #seperating each query word and adding "and" if there is no operator between words
    for i in range(0,len(q_words)):
        if i==0:
            sep_words=[q_words[0]]
            continue
        if q_words[i] not in li1:
            if sep_words[-1] in li1:
                sep_words.append(q_words[i])
            else:
                sep_words.append("and")
                sep_words.append(q_words[i])
        elif sep_words[-1] not in li1:
            sep_words.append(q_words[i])
    return sep_words

#this function help to sepeate operator and normal words used in query
def seperate(sep_words,op,normal_words):
    for i in sep_words:
        if i in li1:
            op.append(i)
        else:
            normal_words.append(i)
    return op,normal_words        

n=len(file_with_index)
#function helps to take "and"/"or" between generated vector list
def cons_vector(normal_words):
    vec_matrix1=[]
    for i in normal_words:
        vec=[0]*n
        if i in unique_words:
            for j in posting_list[i].keys():
                vec[j]=1
        vec_matrix1.append(vec)
    return vec_matrix1

def take_op(vector1,vector2,op):
    ans=[]
    for b1,b2 in zip(vector1,vector2):
        if op=="and":
            ans.append(b1&b2)
        else:
            ans.append(b1|b2)
    return ans

for key,value in query_list.items():
    q_words=cleaning(key)
    sep_words=add(q_words)
    # print(sep_words)
    op=[]
    normal_words=[]
    #getting seperated operator and normal words list
    op,normal_words=seperate(sep_words,op,normal_words)
    vec_matrix=cons_vector(normal_words)
    #iterating over all operators and performing boolean operation according to operator
    for w in op:
        vector1=vec_matrix[0]
        vector2=vec_matrix[1]
        temp=take_op(vector1,vector2,w)
        #poping out 1st two used vector and adding result after performing boolean operation 
        vec_matrix.pop(0)
        vec_matrix.pop(0)
        vec_matrix.insert(0,temp)
    #getting all relevant file names
    final_word_vector=vec_matrix[0]
    cnt=0
    final_score={}
    for i in final_word_vector:    
        final_score[file_with_index[cnt]]=i
        cnt+=1
    
    final_score = sorted(final_score.items(),key=lambda x:x[1],reverse=True)
    cnt=5
    for i in final_score:
        if cnt==0:
            break
        cnt-=1
        txt = i[0].split(".")[0]
        master_list[key].append(txt)
        if i[1]==0:
            rel[key].append(0)
        else:
            rel[key].append(1)

df = pd.DataFrame(columns=['QueryId','Iteration','Docid','Relevence'])

final_list = []
the_list = []
for i in range(4):
    the_list.append([])      

for k,v, in query_list.items():
    docid = v
    i=0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name)
        i+=1
    for j in rel[k]:
        the_list[3].append(j)

df['QueryId'] = the_list[0]
df['Iteration'] = the_list[1]
df['Docid'] = the_list[2]
df['Relevence'] = the_list[3]
# df['relevence'] = the_list[4]=

df.to_csv('QRels_BRS.csv',index=False)

df




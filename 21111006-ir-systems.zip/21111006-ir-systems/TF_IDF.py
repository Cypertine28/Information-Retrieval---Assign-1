import numpy as np
import os
import sys
import re
import math
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import sent_tokenize , word_tokenize
import glob
from pathlib import Path
from collections import Counter
ps=PorterStemmer()
import pandas as pd
import numpy as np

with open('../pickle files/doc_fre.pkl','rb') as file:
    doc_fre=pickle.load(file)
    file.close()
    
with open('../pickle files/files_with_index.pkl','rb') as file:
    file_with_index=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_word.pkl','rb') as file:
    doc_words=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_norm.pkl','rb') as file:
    doc_norm=pickle.load(file)
    file.close()

with open('../pickle files/posting_list.pkl','rb') as file:
    posting_list=pickle.load(file)
    file.close()
    
with open('../pickle files/doc_len.pkl','rb') as file:
    doc_len=pickle.load(file)
    file.close()

def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

query_list = {}
file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')

for q in query:
    new_text = q.split("\t")
    query_list[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")

li=stopwords.words('english')
Stopwords={}
for i in li:
    Stopwords[i]=1

master_list = {}
rel={}
for k,v in query_list.items():
    master_list[k]=[]
    rel[k]=[]

def cleaning(query):
    #remove the punctuations
    text = re.sub(r'[^\w\s]',' ',query)
    # removing nonascii characters
    encoded_string = text.encode("ascii", "ignore")
    text = encoded_string.decode()
    # tokenizing the doc texts
    tokenize_words=word_tokenize(text)
    # lower all the words
    tokenize_words = [word.lower() for word in tokenize_words]
    #procedure to convert num to words
    temp=[]
    for w in tokenize_words:
        try:
            w=num2words(int(w))
        except:
            pass
        temp.append(w)
    tokenize_words=temp
    # stemming each word
    tokenize_words = [ps.stem(word) for word in tokenize_words]
    #removing all stopwords from query
    tokenize_words=[word for word in tokenize_words if word not in Stopwords]
    #remove all unnecessory words which not present in any dictionary
    words=[word for word in tokenize_words if word in posting_list.keys()]
    return words

def build_query_vector(words):
    vec=[]
    temp=0
    for w in words:
        tf_idf=(words.count(w)*math.log(len(file_with_index)/doc_fre[w]))
        vec.append(tf_idf)
        temp+=tf_idf**2
    q_norm=math.sqrt(temp)
    vec=np.array(vec)/q_norm
    return vec
def build_d_vec(words,i):
    vec=[]
    for w in words:
        tf_idf=(doc_words[i].count(w)*math.log(len(file_with_index)/doc_fre[w]))
        vec.append(tf_idf)
    vec=np.array(vec)/doc_norm[i]
    return vec

def tf_idf_function(query): 
    words=cleaning(query)
    #building vector for query
    q_vector=build_query_vector(words)

    score={}
    #proccessing for each document
    for i in range(len(file_with_index)):
        d_vec=build_d_vec(words,i)
        #finding cosine simalarity for each doc and query vector
        score[i]=np.dot(q_vector,d_vec)

    return score


for key,value in query_list.items():
    score=tf_idf_function(key)
    final_score = {}
    for i in score:
        final_score[file_with_index[i]]=score[i]

    final_score = sorted(final_score.items(),key=lambda x:x[1],reverse=True)
    
    cnt=5
    for i in final_score:
        if cnt==0:
            break
        cnt-=1
        txt = i[0].split(".")[0]
        master_list[key].append(txt)
        if i[1]==0:
            rel[key].append(0)
        else:
            rel[key].append(1)

df = pd.DataFrame(columns=['QueryId','Iteration','Docid','Relevence'])

final_list = []
the_list = []
for i in range(4):
    the_list.append([])      

for k,v, in query_list.items():
    docid = v
    i=0
    for doc_name in master_list[k]:
        the_list[0].append(v)
        the_list[1].append(1)
        the_list[2].append(doc_name)
        i+=1
    for j in rel[k]:
        the_list[3].append(j)

df['QueryId'] = the_list[0]
df['Iteration'] = the_list[1]
df['Docid'] = the_list[2]
df['Relevence'] = the_list[3]
# df['relevence'] = the_list[4]=

df.to_csv('QRels_TF_IDF.csv',index=False)


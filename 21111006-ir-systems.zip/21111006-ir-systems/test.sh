python3 BM25.py $1
echo bm25 done
python3 TF_IDF.py $1
echo TF-IDF done
python3 BRS.py $1
echo BRS done